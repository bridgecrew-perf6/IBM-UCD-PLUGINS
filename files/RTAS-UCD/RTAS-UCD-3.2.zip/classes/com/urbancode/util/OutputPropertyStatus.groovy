package com.urbancode.util;

/*
 * This enum holds the applicable values for the step execution status in UCD/Launch server
 */
public enum OutputPropertyStatus {
	SUCCESS("Success"),
	FAILURE("Failure");

	private final String status;

	OutputPropertyStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return status;
	}
}
